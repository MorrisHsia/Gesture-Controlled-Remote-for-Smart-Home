

/**
 *    Keil project for I2C peripheral
 *
 *  Before you start, select your target, on the right of the "Load" button
 *
 *    @author        Tilen Majerle
 *    @email        tilen@majerle.eu
 *    @website    http://stm32f4-discovery.net
 *    @ide        Keil uVision 5
 *    @packs        STM32F4xx Keil packs version 2.2.0 or greater required
 *    @stdperiph    STM32F4xx Standard peripheral drivers version 1.4.0 or greater required
 */
/* Include core modules */
#include "stm32f4xx.h"
#include "stm32f4xx_usart.h"
/* Include my libraries here */
#include "apds9960.h"
#include "defines.h"
#include "tm_stm32f4_i2c.h"
#include "typedef.h"
#include "delay.h"
#include "stm32f4xx_spi.h"
#include "defines.h"
#include "tm_stm32f4_ili9341.h"
#include "tm_stm32f4_fonts.h"
#include <stdio.h>
#include "battery.h"
//Application
volatile int Gesture_Flag;
int gesture = 0;

/* ----------------------------------------------------------------------------*
 *
 * Function Name : EXTI0_Config
 *
 * Description   : Configuring External Interrupt for Gesture INT Pin
 *
 * Input: None
 *
 * Output  : None
 *
 * Return  : None
 * ----------------------------------------------------------------------------*
 * Authors: Sarath S
 * Date: May 17, 2017
 * ---------------------------------------------------------------------------*/
//void EXTI1_Config(void);

//void micro_wait(unsigned int micro_seconds);

void toggleLED(int pin){

    RCC->AHB1ENR |= RCC_AHB1ENR_GPIODEN;
    GPIOD->MODER &= ~(0xff << 24);
    GPIOD->MODER |= 0x55<<24;

   // GPIOD->MODER &= ~(0x3f << 10);
   // GPIOD->MODER |= 0x15<<10;
    //GPIO_ToggleBits(GPIOD, pin);
    GPIOD->ODR |= pin;
}

void turnoffLED(int pin){
    RCC->AHB1ENR |= RCC_AHB1ENR_GPIODEN;
    GPIOD->MODER &= ~(0xff << 24);
    GPIOD->MODER |= 0x55<<24;

   // GPIOD->MODER &= ~(0x3f << 10);
   // GPIOD->MODER |= 0x15<<10;

    GPIOD->ODR &= ~(1<<pin);
}

void EXTI4_Config(void)
{
  EXTI_InitTypeDef   EXTI_InitStructure;
  GPIO_InitTypeDef   GPIO_InitStructure;
  NVIC_InitTypeDef   NVIC_InitStructure;
  /* Enable GPIOB clock */
  //RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOB, ENABLE);
  RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOD,ENABLE);
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_SYSCFG, ENABLE);

  /* Configure PB.01 pin as input floating */
  GPIO_InitTypeDef GPIO_InitStruct;
  GPIO_InitStruct.GPIO_Mode = GPIO_Mode_IN;
  GPIO_InitStruct.GPIO_OType = GPIO_OType_PP;
  //GPIO_InitStruct.GPIO_Pin = GPIO_Pin_1;
  //PD2 as new interrupt pin
  GPIO_InitStruct.GPIO_Pin = GPIO_Pin_4;
  GPIO_InitStruct.GPIO_PuPd = GPIO_PuPd_UP;
  GPIO_InitStruct.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_Init(GPIOD, &GPIO_InitStruct);

//  RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO, ENABLE);
//  GPIO_EXTILineConfig(GPIO_PortSourceGPIOB, GPIO_PinSource1);
//  RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO, DISABLE);
  //SYSCFG_EXTILineConfig(EXTI_PortSourceGPIOB, EXTI_PinSource1);
  //EXTI_ClearITPendingBit(EXTI_Line1);
  SYSCFG_EXTILineConfig(EXTI_PortSourceGPIOD, EXTI_PinSource4);
  EXTI_ClearITPendingBit(EXTI_Line4);
  /* Configure EXTI0 line */
  //EXTI_InitStructure.EXTI_Line = EXTI_Line1;
  EXTI_InitStructure.EXTI_Line = EXTI_Line4;
  EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;
  EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Rising_Falling;
  EXTI_InitStructure.EXTI_LineCmd = ENABLE;
  EXTI_Init(&EXTI_InitStructure);

  /* Enable and set EXTI0 Interrupt to the lowest priority */
  //NVIC_InitStructure.NVIC_IRQChannel = EXTI1_IRQn;
  NVIC_InitStructure.NVIC_IRQChannel = EXTI4_IRQn;
  NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0x0F;
  NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0x0F;
  NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
  // EXTI0_IRQn has Most important interrupt
  NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0x00;
  NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0x00;

  NVIC_Init(&NVIC_InitStructure);
}/* End of this function */

void EXTI4_IRQHandler(void)
{
    if(EXTI_GetITStatus(EXTI_Line4) != RESET)
    {
        Gesture_Flag = 1;
        // Clear the  EXTI line 0 pending bit //
        EXTI_ClearITPendingBit(EXTI_Line4);
    }

}

void systemClockInit(void)
{
  SysTick_Config(SystemCoreClock / 1000);
}

void USART_Config(void)
{
//    // Enable clock for GPIOD
//    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOD, ENABLE);
//     // Enable clock for USART3
//    RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART3, ENABLE);
//    // Connect PD5 to USART1_Tx
//    GPIO_PinAFConfig(GPIOD, GPIO_PinSource5, GPIO_AF_USART3);
//    // Connect PD6 to USART1_Rx
//    GPIO_PinAFConfig(GPIOD, GPIO_PinSource6, GPIO_AF_USART3);
//
//    // Initialization of GPIOD
//    GPIO_InitTypeDef GPIO_InitStruct;
//    GPIO_InitStruct.GPIO_Pin = GPIO_Pin_5 | GPIO_Pin_6;
//    GPIO_InitStruct.GPIO_Mode = GPIO_Mode_AF;
//    GPIO_InitStruct.GPIO_Speed = GPIO_Speed_50MHz;
//    GPIO_InitStruct.GPIO_OType = GPIO_OType_PP;
//    GPIO_InitStruct.GPIO_PuPd = GPIO_PuPd_UP;
//    GPIO_Init(GPIOD, &GPIO_InitStruct);
//
    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOC, ENABLE);
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART3, ENABLE);
    // Connect PD5 to USART1_Tx
    GPIO_PinAFConfig(GPIOC, GPIO_PinSource10, GPIO_AF_USART3);
    // Connect PD6 to USART1_Rx
    GPIO_PinAFConfig(GPIOC, GPIO_PinSource11, GPIO_AF_USART3);

    // Initialization of GPIOD
    GPIO_InitTypeDef GPIO_InitStruct;
    GPIO_InitStruct.GPIO_Pin = GPIO_Pin_10 | GPIO_Pin_11;
    GPIO_InitStruct.GPIO_Mode = GPIO_Mode_AF;
    GPIO_InitStruct.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStruct.GPIO_OType = GPIO_OType_PP;
    GPIO_InitStruct.GPIO_PuPd = GPIO_PuPd_UP;
    GPIO_Init(GPIOC, &GPIO_InitStruct);

//    //PC4 5 set to 1

    GPIOC->MODER &= ~(0xf << 8);
    GPIOC->MODER |= 0x5 << 8;
    GPIOC->ODR |= 0x3 << 4;

    // Initialization of USART3
    USART_InitTypeDef USART_InitStruct;
    //USART_InitStruct.USART_BaudRate = 31296;//3.26
    //USART_InitStruct.USART_BaudRate = 363626;//115200 * 3.156
    USART_InitStruct.USART_BaudRate = 115200;//115200 * 3.156
    USART_InitStruct.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
    USART_InitStruct.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;
    USART_InitStruct.USART_Parity = USART_Parity_No;
    USART_InitStruct.USART_StopBits = USART_StopBits_1;
    USART_InitStruct.USART_WordLength = USART_WordLength_8b;
    USART_Init(USART3, &USART_InitStruct);
    //USART3->BRR = (uint8_t)(8.6875);
    // Enable USART3
    USART_Cmd(USART3, ENABLE);
}


void uart_send_buff(uint8_t buf[],uint32_t len) {
    uint32_t i;
    for(i=0;i<len;i++) {
        USART_SendData(USART3,(uint8_t)buf[i]);
        while(USART_GetFlagStatus(USART3,USART_FLAG_TXE)==RESET);
    }
    USART_SendData(USART3,(uint8_t)'\r');
    while(USART_GetFlagStatus(USART3,USART_FLAG_TXE)==RESET);
    USART_SendData(USART3,(uint8_t)'\n');
    while(USART_GetFlagStatus(USART3,USART_FLAG_TXE)==RESET);
    bzero(buf,sizeof(buf));
}

void ifttt(void){

    // Send "AT" command to confirm
    uart_send_buff("AT\r\n", strlen("AT\r\n"));
    micro_wait(500000);
    // Set CWMODE = 3 "AT+CWMODE=3"
    uart_send_buff("AT+CWMODE=3\r\n", strlen("AT+CWMODE=3\r\n"));
    micro_wait(500000);
    // Connect to the wifi
    uart_send_buff("AT+CWJAP=\"NETGEAR10\",\"bluequail402\"\r\n", strlen("AT+CWJAP=\"NETGEAR10\",\"bluequail402\"\r\n"));
    micro_wait(3000000);
    // CIFSR
    uart_send_buff("AT+CIFSR", strlen("AT+CIFSR"));
    micro_wait(1000000);
}

void cipstart(void){
    // Connect with maker.ifttt.com
       uart_send_buff("AT+CIPSTART=\"TCP\",\"maker.ifttt.com\",80\r\n", strlen("AT+CIPSTART=\"TCP\",\"maker.ifttt.com\",80\r\n"));
}

void cipclose(void){
    uart_send_buff("AT+CIPCLOSE", strlen("AT+CIPCLOSE"));
}

void ifttt_command(char* eventName){

    // Start cip
    cipstart();
    micro_wait(1000000);
    int len = strlen("GET /trigger//with/key/XL7TaWxEd5H0gmAoe8aPE HTTP/1.1\r\nHOST: maker.ifttt.com\r\n\r\n\r\n") + strlen(eventName);
    char* url = malloc(sizeof(char) * len);
    sprintf(url, "GET /trigger/%s/with/key/XL7TaWxEd5H0gmAoe8aPE HTTP/1.1\r\nHOST: maker.ifttt.com\r\n\r\n\r\n", eventName);

    char * cipsend = malloc(sizeof(char) * (strlen("AT+CIPSEND=\r\n") + 2));
    sprintf(cipsend, "AT+CIPSEND=%d\r\n", len);

    // Send CIPSEND=
    uart_send_buff(cipsend, strlen(cipsend));
    micro_wait(100000);
    // Send the event
    uart_send_buff(url, strlen(url));
    micro_wait(1000000);
    // Close cip
    cipclose();
}

int main(void) {


    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_4);

    // Initialize
    //systemClockInit(); // worked without systemClockInit
    USART_Config();
    ifttt();
    //uart_send_buff("hello\n", strlen("hello\n"));

    if (!apds9960init()){
        uart_send_buff("apds9960init() failed!\n", strlen("apds9960init() failed!\n"));
    }
    //uart_send_buff("apds9960init() successful!\n", strlen("apds9960init() successful!\n"));

    // Enable gesture sensor
    if ( !enableGestureSensor(true)){
        // if not enabled, toggle an LED
        uart_send_buff("enableGestureSensor(true) failed!", strlen("enableGestureSensor(true) failed!"));
    }
    //uart_send_buff("enableGestureSensor(true) successful!", strlen("enableGestureSensor(true) successful!"));

    // After calling enbleGestureSensor(true)...
    //         Reg Addr.                  Value
    // 0x80 (Enable Register)        0b01001101
    // 0x83 (Wait Time)                   0xFF
    // 0x8E (Proximity)                0x89
    // 0xAB (GCONF4)                   0xFF
    uint8_t enable, wait, prox, gconf4_main;
    enable = TM_I2C_Read(I2C2, APDS9960_I2C_ADDR << 1, APDS9960_ENABLE);
    wait = TM_I2C_Read(I2C2, APDS9960_I2C_ADDR << 1, APDS9960_WTIME);
    prox = TM_I2C_Read(I2C2, APDS9960_I2C_ADDR << 1, APDS9960_PPULSE);
    gconf4_main = TM_I2C_Read(I2C2, APDS9960_I2C_ADDR << 1, APDS9960_GCONF4);

    // Configure external interrupt 0
    EXTI4_Config();

    //Initialize system
    //SystemInit();

    //Initialize ILI9341
    TM_ILI9341_Init();
    //Rotate LCD for 90 degrees
    TM_ILI9341_Rotate(TM_ILI9341_Orientation_Landscape_2);
    //FIll lcd with color
    TM_ILI9341_Fill(ILI9341_COLOR_GREEN2);
    //Draw white circle
    TM_ILI9341_DrawCircle(60, 60, 40, ILI9341_COLOR_GREEN);
    //Draw red filled circle
    TM_ILI9341_DrawFilledCircle(60, 60, 35, ILI9341_COLOR_RED);
    //Draw blue rectangle
    TM_ILI9341_DrawRectangle(120, 20, 220, 100, ILI9341_COLOR_BLUE);
    //Draw black filled rectangle
    TM_ILI9341_DrawFilledRectangle(130, 30, 210, 90, ILI9341_COLOR_BLACK);
    //Draw line with custom color 0x0005
    TM_ILI9341_DrawLine(10, 120, 310, 120, 0x0005);
    //Put string with black foreground color and blue background with 11x18px font
    TM_ILI9341_Puts(65, 130, "PSSC", &TM_Font_11x18, ILI9341_COLOR_BLACK, ILI9341_COLOR_BLUE2);
    //Put string with black foreground color and blue background with 11x18px font
    TM_ILI9341_Puts(110, 150, "ILI9341", &TM_Font_11x18, ILI9341_COLOR_BLACK, ILI9341_COLOR_BLUE2);
    //Put string with black foreground color and red background with 11x18px font
    TM_ILI9341_Puts(245, 225, "TEAM10", &TM_Font_7x10, ILI9341_COLOR_BLACK, ILI9341_COLOR_ORANGE);
    TM_ILI9341_Puts(60, 170, "UP/DOWN LEFT/RIGHT", &TM_Font_11x18, ILI9341_COLOR_BLACK, ILI9341_COLOR_BLUE2);
//    TM_ILI9341_Puts(100, 190, "MUSIC/LIGHT", &TM_Font_11x18, ILI9341_COLOR_BLACK, ILI9341_COLOR_BLUE2);
    //Gesture_Flag = 1;

    while (1)
    {
        //test main PCB
//        toggleLED(GPIO_Pin_14);
//        micro_wait(50000);
//        turnoffLED(14);
//        micro_wait(50000);
////
        //gesture sensor

        if(Gesture_Flag)  /*  External Interuput0 Flag */
        {
            //ifttt_command("turn_on_hue");
            NVIC_DisableIRQ(EXTI4_IRQn);
            gesture = apds9960ReadSensor(); /* Read Gesture */
//            char* gesture_ret = malloc(sizeof(char) * 20);
//            sprintf(gesture_ret, "gesture = %d\n", gesture);
//            uart_send_buff(gesture_ret, strlen(gesture_ret));

            if(gesture==3){
                ifttt_command("turn_on_hue");
                //uart_send_buff("3: UP\n", strlen("3: UP\n"));
                //TM_ILI9341_Fill(ILI9341_COLOR_BLUE2);
                //TM_ILI9341_Puts(110, 100, "UP", &TM_Font_16x26, ILI9341_COLOR_BLACK, ILI9341_COLOR_BLUE2);
            }
            else if(gesture==4){
                ifttt_command("turn_off_hue");
                //uart_send_buff("4: DOWN\n", strlen("4: DOWN\n"));
                TM_ILI9341_Fill(ILI9341_COLOR_BLUE);
                TM_ILI9341_Puts(110, 100, "DOWN", &TM_Font_16x26, ILI9341_COLOR_BLACK, ILI9341_COLOR_BLUE2);
            }
            else if(gesture==1){
                ifttt_command("change_color");
                //uart_send_buff("1: LEFT\n", strlen("4: LEFT\n"));
                TM_ILI9341_Fill(ILI9341_COLOR_RED);
                TM_ILI9341_Puts(110, 100, "LEFT", &TM_Font_16x26, ILI9341_COLOR_BLACK, ILI9341_COLOR_BLUE2);
            }
            else if(gesture==2){
                ifttt_command("color_loop");
                //uart_send_buff("2: RIGHT\n", strlen("2: RIGHT\n"));
                TM_ILI9341_Fill(ILI9341_COLOR_CYAN);
                TM_ILI9341_Puts(110, 100, "RIGHT", &TM_Font_16x26, ILI9341_COLOR_BLACK, ILI9341_COLOR_BLUE2);
            }

            //TM_ILI9341_Fill(ILI9341_COLOR_GREEN2);
            // Battery
            micro_wait(2000000);
            int battery;
            Gesture_Flag = 0;
            NVIC_EnableIRQ(EXTI4_IRQn);
        }
    }

}

