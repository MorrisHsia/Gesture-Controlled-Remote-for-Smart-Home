#include "battery.h"
#include "stdlib.h"
#include "tm_stm32f4_i2c.h"



uint16_t value;

int batteryinit(){
    uint8_t ID;
    /* Initialize I2C, SCL:PB10  and SDA:PB11:  with 100kHt serial clock */
    TM_I2C_Init(I2C2, TM_I2C_PinsPack_1, 100000);
    //ID = TM_I2C_Read(I2C2, BATTERY_SLAVE << 1,ID);

}


/*============================================================================*/

void MAX17048_Init(MAX17048_t *Obj, Write_Fcn Write, Read_Fcn Read, uint8_t Addres_Device){

  Obj->Write = Write;

  Obj->Read = Read;

  Obj->Address = Addres_Device;

}
/*============================================================================*/

void MAX17048_Write(MAX17048_t *Obj, uint8_t Reg, uint16_t data, uint8_t amount){

  uint8_t buffer[3];



  buffer[0] = Reg;

  buffer[1] = data >> 8;

  buffer[2] = data;

  Obj->Write(Obj->Address, (void*)buffer, (amount+1));

}

/*============================================================================*/

uint16_t MAX17048_Read(MAX17048_t *Obj, uint8_t Reg, uint8_t amount){

  uint8_t buffer[2];

  buffer[0] = Reg;

  Obj->Read(Obj->Address, buffer, amount);

  return buffer[0] << 8 | buffer[1];

}

/*============================================================================*/

uint8_t adc(void){
    return (float)(TM_I2C_Read(I2C2, BATTERY_SLAVE << 1, VCELL));
}

float voltage(void){
    return (float)(TM_I2C_Read(I2C2, BATTERY_SLAVE << 1, VCELL)) * 0.000078125f;
}

uint8_t percent(void){
    return (uint8_t)(TM_I2C_Read(I2C2, BATTERY_SLAVE << 1, VCELL)) / 256;
}
