#include "stm32f4xx.h"
#include "tm_stm32f4_i2c.h"

#define BATTERY_SLAVE 0x36
#define WRITE 0x0
#define READ 0x1

#define VCELL 0x02
#define SOC 0x04
#define MODE 0x06
#define VERSION 0x08
#define HIBRT 0x0A
#define CONFIG 0x0C
#define VALRT 0x14
#define CRATE 0x16
#define VRESET 0x18
//#define ID     0x19
#define STATUS 0x1A
#define TABLE 0x40
#define CMD 0xFE

#define RI 1
#define VH 1 << 1
#define VL 1 << 2
#define VR 1 << 3
#define HD 1 << 4
#define SC 1 << 5


typedef void (*Write_Fcn )(uint8_t, void*, uint8_t);
typedef void (*Read_Fcn  )(uint8_t, void*, uint8_t);
typedef struct {
    Write_Fcn Write;
    Read_Fcn  Read;
    uint8_t   Address;
}MAX17048_t;

void MAX17048_Init(MAX17048_t *Obj, Write_Fcn Write, Read_Fcn Read, uint8_t Addres_Device);

void MAX17048_Write(MAX17048_t *Obj, uint8_t Reg, uint16_t data, uint8_t amount);

uint16_t MAX17048_Read(MAX17048_t *Obj, uint8_t Reg, uint8_t amount);


int batteryinit();

uint8_t adc(void);

float voltage(void);

uint8_t percent(void);
