#include "stm32f4xx.h"

#define LEFT 3
#define RIGHT 2
#define UP 1
#define DOWN 0

#define PB_MOSI (5)
#define PB_SCK (3)
#define PA_DC (3)
#define PA_CS (6)
#define PA_RST (2)
#define PA_LITE (1)
// SPI1 SCK: PB3
// SPI1 MISO: PB4
// SPI1 MOSI: PB5
// SPI1 CS: PA6
// SPI1 DC: PA3
// SPI1 RST: PA2
// SPI1 LITE: PA1

#define ROW_NUM ((uint16_t)320)
#define COLUMN_NUM ((uint16_t)240)

void hspi1_init();
void hspi_gpio_init();
void hspi_w8(SPI_TypeDef *SPIx, uint8_t dat);
void hspi_w16(SPI_TypeDef *SPIx, uint16_t dat);
void hspi_cmd(SPI_TypeDef *SPIx, uint8_t cmd);
void set16bmode(SPI_TypeDef *SPIx);
void set8bmode(SPI_TypeDef *SPIx);
void ili9341_hspi_init(SPI_TypeDef *SPIx);
void spi_init(SPI_TypeDef *SPIx);
void CleanScreen();
void draw_zero();
void draw_one();
void pixel_test();
void setAddrWindow(uint16_t x1, uint16_t y1, uint16_t w, uint16_t h);
void writeColor(uint16_t color, uint32_t len);
