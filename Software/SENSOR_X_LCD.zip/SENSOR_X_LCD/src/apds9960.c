#include "stm32f4xx.h"
/* Include my libraries here */
#include "apds9960.h"
#include "defines.h"
#include "tm_stm32f4_i2c.h"
#include "typedef.h"
#include "stdlib.h"

void micro_wait(unsigned int micro_seconds);

gesture_data_type gesture_data_;
int gesture_ud_delta_;
int gesture_lr_delta_;
int gesture_ud_count_;
int gesture_lr_count_;
int gesture_near_count_;
int gesture_far_count_;
int gesture_state_;
int gesture_motion_;

int apds9960init(){
	uint8_t ID;
	uint8_t testwrite;

	/* Initialize system */
	SystemInit();

	/* Initialize I2C, SCL: PB6 or PB8 and SDA: PB7 with 100kHt serial clock */
	//toggleLED(GPIO_Pin_15);
	TM_I2C_Init(I2C2, TM_I2C_PinsPack_1, 100000);

	//toggleLED(GPIO_Pin_15);
	/* Get ID from sensor 0xab */
	ID = TM_I2C_Read(I2C2, APDS9960_I2C_ADDR << 1, APDS9960_ID);
	char * id = malloc(sizeof(char) * 10);
	sprintf(id, "id = %x\n", ID);
	//uart_send_buff(id, strlen(id));
	//if(ID == 0xab){uart_send_buff("apds9960init()\n", strlen("apds9960init()\n"));}
	/*//try write
	TM_I2C_Write(I2C2, APDS9960_I2C_ADDR << 1, APDS9960_GPENTH, 0xcd);
	testwrite = TM_I2C_Read(I2C2, APDS9960_I2C_ADDR << 1, APDS9960_GPENTH);*/

	//disable all feature of sensor
	int mode = setMode(ALL,OFF);
	uint8_t sr = TM_I2C_Read(I2C2, APDS9960_I2C_ADDR << 1, APDS9960_ENABLE);
	if(!mode){return 0;}

	// Set default values for ambient light and proximity registers
	TM_I2C_Write(I2C2, APDS9960_I2C_ADDR << 1, APDS9960_ATIME, DEFAULT_ATIME); //ADC integration time
	TM_I2C_Write(I2C2, APDS9960_I2C_ADDR << 1, APDS9960_WTIME, DEFAULT_WTIME); //Wait time (non-gesture)
	TM_I2C_Write(I2C2, APDS9960_I2C_ADDR << 1, APDS9960_PPULSE, DEFAULT_PROX_PPULSE); //Proximity pulse count and length
	TM_I2C_Write(I2C2, APDS9960_I2C_ADDR << 1, APDS9960_POFFSET_UR, DEFAULT_POFFSET_UR); //proximity offset for UP and RIGHT photodiodes
	TM_I2C_Write(I2C2, APDS9960_I2C_ADDR << 1, APDS9960_POFFSET_DL, DEFAULT_POFFSET_DL); //proximity offset for DOWN and LEFT photodiodes
	TM_I2C_Write(I2C2, APDS9960_I2C_ADDR << 1, APDS9960_CONFIG1, DEFAULT_CONFIG1); //gesture configuration 1

	int p_gain = setProximityGain(DEFAULT_PGAIN);
	if(!p_gain){return 0;}
	int a_gain = setAmbientLightGain(DEFAULT_AGAIN);
	if(!a_gain){return 0;}
	int pilt = setProxIntLowThresh(DEFAULT_PILT); //proximity interrupt low threshold
	if(!pilt){return 0;}
	int piht = setProxIntHighThresh(DEFAULT_PIHT); //proximity interrupt high threshold
	if(!piht){return 0;}
	int ailt = setLightIntLowThreshold(DEFAULT_AILT); //ALS interrupt low threshold
	if(!ailt){return 0;}
	int alht = setLightIntHighThreshold(DEFAULT_AIHT); //ALS interrupt high threshold
	if(!alht){return 0;}

	TM_I2C_Write(I2C2, APDS9960_I2C_ADDR << 1, APDS9960_PERS, DEFAULT_PERS);
	TM_I2C_Write(I2C2, APDS9960_I2C_ADDR << 1, APDS9960_CONFIG2, DEFAULT_CONFIG2);
	TM_I2C_Write(I2C2, APDS9960_I2C_ADDR << 1, APDS9960_CONFIG3, DEFAULT_CONFIG3);


	// Set default values for gesture sense registers
	int enter_thres_gesture = setGestureEnterThresh(DEFAULT_GPENTH);
	int exit_thres_gesture = setGestureExitThresh(DEFAULT_GEXTH);
	TM_I2C_Write(I2C2, APDS9960_I2C_ADDR << 1, APDS9960_GCONF1, DEFAULT_GCONF1);
	int gesture_gain = setGestureGain(DEFAULT_GGAIN);
	int set_wait_gesture = setGestureWaitTime(DEFAULT_GWTIME);
	TM_I2C_Write(I2C2, APDS9960_I2C_ADDR << 1, APDS9960_GOFFSET_U, DEFAULT_GOFFSET);
	TM_I2C_Write(I2C2, APDS9960_I2C_ADDR << 1, APDS9960_GOFFSET_D, DEFAULT_GOFFSET);
	TM_I2C_Write(I2C2, APDS9960_I2C_ADDR << 1, APDS9960_GOFFSET_L, DEFAULT_GOFFSET);
	TM_I2C_Write(I2C2, APDS9960_I2C_ADDR << 1, APDS9960_GOFFSET_R, DEFAULT_GOFFSET);
	TM_I2C_Write(I2C2, APDS9960_I2C_ADDR << 1, APDS9960_GPULSE, DEFAULT_GPULSE);
	TM_I2C_Write(I2C2, APDS9960_I2C_ADDR << 1, APDS9960_GCONF3, DEFAULT_GCONF3);
	int Int_en_gesture = setGestureIntEnable(DEFAULT_GIEN);

	return 1;
}

int setMode(uint8_t mode, uint8_t enable){
    uint8_t reg_val;

    /* Read current ENABLE register */
    reg_val = getMode();
    if( reg_val == ERROR ) {
        return false;
    }

    /* Change bit(s) in ENABLE register */
    enable = enable & 0x01;
    if( mode >= 0 && mode <= 6 ) {
        if (enable) {
            reg_val |= (1 << mode);
        } else {
            reg_val &= ~(1 << mode);
        }
    } else if( mode == ALL ) {
        if (enable) {
            reg_val = 0x7F;
        } else {
            reg_val = 0x00;
        }
    }

    /* Write value back to ENABLE register */
    TM_I2C_Write(I2C2,APDS9960_I2C_ADDR << 1, APDS9960_ENABLE, reg_val);

    return true;
}

uint8_t getMode(void)
{
	uint8_t enable_value;

    /* Read current ENABLE register */
  	enable_value = TM_I2C_Read(I2C2, APDS9960_I2C_ADDR << 1, APDS9960_ENABLE);

    return enable_value;
}

int setProximityGain(uint8_t drive)
{
    uint8_t val;

    /* Read value from CONTROL register */
    val = TM_I2C_Read(I2C2, APDS9960_I2C_ADDR << 1, APDS9960_CONTROL);

    /* Set bits in register to given value */
    drive &= 0x03;
    drive = drive << 2;
    val &= 0xF3;
    val |= drive;

    /* Write register value back into CONTROL register */
    TM_I2C_Write(I2C2,APDS9960_I2C_ADDR << 1, APDS9960_CONTROL, val);

    return true;
}/* End of this function */

int setAmbientLightGain(uint8_t drive)
{
    uint8_t val;

    /* Read value from CONTROL register */
    val = TM_I2C_Read(I2C2, APDS9960_I2C_ADDR << 1, APDS9960_CONTROL);

    /* Set bits in register to given value */
    drive &= 0x03;
    val &= 0xFC;
    val |= drive;

    /* Write register value back into CONTROL register */
    TM_I2C_Write(I2C2,APDS9960_I2C_ADDR << 1, APDS9960_CONTROL, val);

    return true;
}/* End of this function */

int setProxIntLowThresh(uint8_t threshold)
{
	TM_I2C_Write(I2C2,APDS9960_I2C_ADDR << 1, APDS9960_PILT, threshold);

    return true;
}/* End of this function */

int setProxIntHighThresh(uint8_t threshold)
{
	TM_I2C_Write(I2C2,APDS9960_I2C_ADDR << 1, APDS9960_PIHT, threshold);

    return true;
}/* End of this function */

int setLightIntLowThreshold(uint16_t threshold)
{
    uint8_t val_low;
    uint8_t val_high;

    /* Break 16-bit threshold into 2 8-bit values */
    val_low = threshold & 0x00FF;
    val_high = (threshold & 0xFF00) >> 8;

    /* Write low byte */
    TM_I2C_Write(I2C2,APDS9960_I2C_ADDR << 1, APDS9960_AILTL, val_low);
    /* Write high byte */
    TM_I2C_Write(I2C2,APDS9960_I2C_ADDR << 1, APDS9960_AILTH, val_high);

    return true;
}/* End of this function */


int setLightIntHighThreshold(uint16_t threshold)
{
    uint8_t val_low;
    uint8_t val_high;

    /* Break 16-bit threshold into 2 8-bit values */
    val_low = threshold & 0x00FF;
    val_high = (threshold & 0xFF00) >> 8;

    /* Write low byte */
    TM_I2C_Write(I2C2,APDS9960_I2C_ADDR << 1, APDS9960_AIHTL, val_low);

    /* Write high byte */
    TM_I2C_Write(I2C2,APDS9960_I2C_ADDR << 1, APDS9960_AIHTL, val_high);

    return true;
}/* End of this function */

//
//
//
//

int setGestureIntEnable(uint8_t enable)
{
    uint8_t val;

    /* Read value from GCONF4 register */
    val = TM_I2C_Read(I2C2, APDS9960_I2C_ADDR << 1, APDS9960_GCONF4);

    /* Set bits in register to given value */
    enable &= 0x01;
    enable = enable << 1;
    val &= 0xFD;
    val |= enable;

    /* Write register value back into GCONF4 register */
    TM_I2C_Write(I2C2,APDS9960_I2C_ADDR << 1, APDS9960_GCONF4, val);

    return true;
}/* End of this function */

int setGestureWaitTime(uint8_t time)
{
    uint8_t val;

    /* Read value from GCONF2 register */
    val = TM_I2C_Read(I2C2, APDS9960_I2C_ADDR << 1, APDS9960_GCONF2);

    /* Set bits in register to given value */
    time &= 0x07;
    val &= 0xF8;
    val |= time;

    /* Write register value back into GCONF2 register */
    TM_I2C_Write(I2C2,APDS9960_I2C_ADDR << 1, APDS9960_GCONF2, val);

    return true;
}/* End of this function */


int setGestureGain(uint8_t gain)
{
    uint8_t val;

    /* Read value from GCONF2 register */
    val = TM_I2C_Read(I2C2, APDS9960_I2C_ADDR << 1, APDS9960_GCONF2);

    /* Set bits in register to given value */
    gain &= 0x03;
    gain = gain << 5;
    val &= 0x9F;
    val |= gain;

    /* Write register value back into GCONF2 register */
    TM_I2C_Write(I2C2,APDS9960_I2C_ADDR << 1, APDS9960_GCONF2, val);

    return true;
}/* End of this function */

int setGestureExitThresh(uint8_t threshold)
{
	TM_I2C_Write(I2C2,APDS9960_I2C_ADDR << 1, APDS9960_GEXTH, threshold);

    return true;
}/* End of this function */


int setGestureEnterThresh(uint8_t threshold)
{
	TM_I2C_Write(I2C2,APDS9960_I2C_ADDR << 1, APDS9960_GPENTH, threshold);

    return true;
}/* End of this function */

int enableGestureSensor(int interrupts)
{

    /* Enable gesture mode
       Set ENABLE to 0 (power off)
       Set WTIME to 0xFF
       Set AUX to LED_BOOST_300
       Enable PON, WEN, PEN, GEN in ENABLE
    */
    resetGestureParameters();
    TM_I2C_Write(I2C2,APDS9960_I2C_ADDR << 1, APDS9960_WTIME, 0XFF);

    TM_I2C_Write(I2C2,APDS9960_I2C_ADDR << 1, APDS9960_PPULSE, DEFAULT_GESTURE_PPULSE);

    int setI;
    if(interrupts){
    	setI = setGestureIntEnable(1);
    }
    else{
    	setI = setGestureIntEnable(0);
    }


    int pow_en = enablePower();
    int mode_wait = setMode(WAIT, 1);
    int mode_prox = setMode(PROXIMITY, 1);
    int mode_gesture = setMode(GESTURE, 1);
    int setmode = setGestureMode(1);
    uint8_t gmode = TM_I2C_Read(I2C2, APDS9960_I2C_ADDR << 1, APDS9960_GCONF4);

    return true;
}/* End of this function */


void resetGestureParameters(void)
{
    gesture_data_.index = 0;
    gesture_data_.total_gestures = 0;

    gesture_ud_delta_ = 0;
    gesture_lr_delta_ = 0;

    gesture_ud_count_ = 0;
    gesture_lr_count_ = 0;

    gesture_near_count_ = 0;
    gesture_far_count_ = 0;

    gesture_state_ = 0;
    gesture_motion_ = DIR_NONE;
}/* End of this function */


int setGestureMode(uint8_t mode)
{
    uint8_t val;

    /* Read value from GCONF4 register */
    val = TM_I2C_Read(I2C2, APDS9960_I2C_ADDR << 1, APDS9960_GCONF4);

    /* Set bits in register to given value */
    mode &= 0x01;
    val &= 0xFE;
    val |= mode;

    /* Write register value back into GCONF4 register */
    TM_I2C_Write(I2C2,APDS9960_I2C_ADDR << 1, APDS9960_GCONF4, val);
    uint8_t gmode = TM_I2C_Read(I2C2, APDS9960_I2C_ADDR << 1, APDS9960_GCONF4);

    return true;
}/* End of this function */

int enablePower(void)
{
	int power = setMode(POWER, 1);

    return true;
}/* End of this function */


int isGestureAvailable(void)
{
    uint8_t val = 0;
    uint8_t gmode;
    uint8_t gdims;
    uint8_t level;

    gmode = TM_I2C_Read(I2C2, APDS9960_I2C_ADDR << 1, APDS9960_GCONF4);
    gdims = TM_I2C_Read(I2C2, APDS9960_I2C_ADDR << 1, APDS9960_GCONF3);
    level = TM_I2C_Read(I2C2, APDS9960_I2C_ADDR << 1, APDS9960_GFLVL);

    /* Read value from GSTATUS register */

    val = TM_I2C_Read(I2C2, APDS9960_I2C_ADDR << 1, APDS9960_GSTATUS);

    /* Shift and mask out GVALID bit */
    val &= APDS9960_GVALID;

    /* Return true/false based on GVALID bit */
    if(val == 1) {
    	toggleLED(GPIO_Pin_15);
    	//micro_wait(1000000);
        return true;
    } else {
    	turnoffLED(15);
        return false;
    }
}/* End of this function */

int readGesture(void)
{
    uint8_t fifo_level = 0;
    int bytes_read = 0;
    uint8_t fifo_data[128];
    uint8_t gstatus;
    int motion;
    int i;


    /* Make sure that power and gesture is on and data is valid */
    if( !isGestureAvailable() || !(getMode() & 0x41) ) {
    	return DIR_NONE;
    }

    /* Keep looping as long as gesture data is valid */
    while(1) {

        /* Wait some time to collect next batch of FIFO data */
        micro_wait(FIFO_PAUSE_TIME);
        /* Get the contents of the STATUS register. Is data still valid? */
    	gstatus = TM_I2C_Read(I2C2, APDS9960_I2C_ADDR << 1, APDS9960_GSTATUS);
//    	if(gstatus == 0){
//    		toggleLED(GPIO_Pin_12);
//    		return ERROR;}

        /* If we have valid data, read in FIFO */
        if( (gstatus & APDS9960_GVALID) == APDS9960_GVALID ) {

        	// Toggle LED if valid data
        	toggleLED(GPIO_Pin_13);
        	micro_wait(10);
        	turnoffLED(13);
            /* Read the current FIFO level */
        	fifo_level = TM_I2C_Read(I2C2, APDS9960_I2C_ADDR << 1, APDS9960_GFLVL);
        	if(fifo_level == -1){return ERROR;}
        	//toggleLED();
            /* If there's stuff in the FIFO, read it into our data block */
            if( fifo_level > 0) {
            	bytes_read = TM_I2C_ReadMulti(I2C2, APDS9960_I2C_ADDR << 1, APDS9960_GFIFO_U, fifo_data, fifo_level * 4);
            	//fifo_data = TM_I2C_Read(I2C2, APDS9960_I2C_ADDR << 1, APDS9960_GFIFO_U);//CHECKKKKKKK
                /*bytes_read = I2C2_read(APDS9960_GFIFO_U,
                                                fifo_data,
                                                (fifo_level * 4) );*/

                if( bytes_read == -1 ) {
                    return ERROR;
                }

                /* If at least 1 set of data, sort the data into U/D/L/R */
                if( bytes_read >= 4 ) {
                    for( i = 0; i < bytes_read; i += 4 ) {
                        gesture_data_.u_data[gesture_data_.index] = fifo_data[i + 0];
                        gesture_data_.d_data[gesture_data_.index] = fifo_data[i + 1];
                        gesture_data_.l_data[gesture_data_.index] = fifo_data[i + 2];
                        gesture_data_.r_data[gesture_data_.index] = fifo_data[i + 3];
                        gesture_data_.index++;
                        gesture_data_.total_gestures++;
                    }

                    /* Filter and process gesture data. Decode near/far state */
                    if( processGestureData() ) {
                        if( decodeGesture() ) {
                            //***TODO: U-Turn Gestures
                        }
                    }

                    /* Reset data */
                    gesture_data_.index = 0;
                    gesture_data_.total_gestures = 0;
                }
            }
        } else {

            /* Determine best guessed gesture and clean up */
            micro_wait(FIFO_PAUSE_TIME);
            decodeGesture();
            motion = gesture_motion_;

            resetGestureParameters();
            return motion;
        }
    }
}


int processGestureData(void)
{
    uint8_t u_first = 0;
    uint8_t d_first = 0;
    uint8_t l_first = 0;
    uint8_t r_first = 0;
    uint8_t u_last = 0;
    uint8_t d_last = 0;
    uint8_t l_last = 0;
    uint8_t r_last = 0;
    int ud_ratio_first;
    int lr_ratio_first;
    int ud_ratio_last;
    int lr_ratio_last;
    int ud_delta;
    int lr_delta;
    int i;

    /* If we have less than 4 total gestures, that's not enough */
    if( gesture_data_.total_gestures <= 4 ) {
        return false;
    }

    /* Check to make sure our data isn't out of bounds */
    if( (gesture_data_.total_gestures <= 32) && (gesture_data_.total_gestures > 0) ) {

        /* Find the first value in U/D/L/R above the threshold */
        for( i = 0; i < gesture_data_.total_gestures; i++ ) {
            if( (gesture_data_.u_data[i] > GESTURE_THRESHOLD_OUT) && (gesture_data_.d_data[i] > GESTURE_THRESHOLD_OUT) && (gesture_data_.l_data[i] > GESTURE_THRESHOLD_OUT) && (gesture_data_.r_data[i] > GESTURE_THRESHOLD_OUT) ) {
                u_first = gesture_data_.u_data[i];
                d_first = gesture_data_.d_data[i];
                l_first = gesture_data_.l_data[i];
                r_first = gesture_data_.r_data[i];
                break;
            }
        }

        /* If one of the _first values is 0, then there is no good data */
        if( (u_first == 0) || (d_first == 0) || (l_first == 0) || (r_first == 0) ) {
            return false;
        }
        /* Find the last value in U/D/L/R above the threshold */
        for( i = gesture_data_.total_gestures - 1; i >= 0; i-- ) {

            if( (gesture_data_.u_data[i] > GESTURE_THRESHOLD_OUT) && (gesture_data_.d_data[i] > GESTURE_THRESHOLD_OUT) && (gesture_data_.l_data[i] > GESTURE_THRESHOLD_OUT) &&(gesture_data_.r_data[i] > GESTURE_THRESHOLD_OUT) ) {
                u_last = gesture_data_.u_data[i];
                d_last = gesture_data_.d_data[i];
                l_last = gesture_data_.l_data[i];
                r_last = gesture_data_.r_data[i];
                break;
            }
        }
    }

    /* Calculate the first vs. last ratio of up/down and left/right */
    ud_ratio_first = ((u_first - d_first) * 100) / (u_first + d_first);
    lr_ratio_first = ((l_first - r_first) * 100) / (l_first + r_first);
    ud_ratio_last = ((u_last - d_last) * 100) / (u_last + d_last);
    lr_ratio_last = ((l_last - r_last) * 100) / (l_last + r_last);

    /* Determine the difference between the first and last ratios */
    ud_delta = ud_ratio_last - ud_ratio_first;
    lr_delta = lr_ratio_last - lr_ratio_first;

    /* Accumulate the UD and LR delta values */
    gesture_ud_delta_ += ud_delta;
    gesture_lr_delta_ += lr_delta;


    /* Determine U/D gesture */
    if( gesture_ud_delta_ >= GESTURE_SENSITIVITY_1 ) {
        gesture_ud_count_ = 1;
    } else if( gesture_ud_delta_ <= -GESTURE_SENSITIVITY_1 ) {
        gesture_ud_count_ = -1;
    } else {
        gesture_ud_count_ = 0;
    }

    /* Determine L/R gesture */
    if( gesture_lr_delta_ >= GESTURE_SENSITIVITY_1 ) {
        gesture_lr_count_ = 1;
    } else if( gesture_lr_delta_ <= -GESTURE_SENSITIVITY_1 ) {
        gesture_lr_count_ = -1;
    } else {
        gesture_lr_count_ = 0;
    }

    /* Determine Near/Far gesture */
    if( (gesture_ud_count_ == 0) && (gesture_lr_count_ == 0) ) {
        if( (abs(ud_delta) < GESTURE_SENSITIVITY_2) && \
            (abs(lr_delta) < GESTURE_SENSITIVITY_2) ) {

            if( (ud_delta == 0) && (lr_delta == 0) ) {
                gesture_near_count_++;
            } else if( (ud_delta != 0) || (lr_delta != 0) ) {
                gesture_far_count_++;
            }

            if( (gesture_near_count_ >= 10) && (gesture_far_count_ >= 2) ) {
                if( (ud_delta == 0) && (lr_delta == 0) ) {
                    gesture_state_ = NEAR_STATE;
                } else if( (ud_delta != 0) && (lr_delta != 0) ) {
                    gesture_state_ = FAR_STATE;
                }
                return true;
            }
        }
    } else {
        if( (abs(ud_delta) < GESTURE_SENSITIVITY_2) && \
            (abs(lr_delta) < GESTURE_SENSITIVITY_2) ) {

            if( (ud_delta == 0) && (lr_delta == 0) ) {
                gesture_near_count_++;
            }

            if( gesture_near_count_ >= 10 ) {
                gesture_ud_count_ = 0;
                gesture_lr_count_ = 0;
                gesture_ud_delta_ = 0;
                gesture_lr_delta_ = 0;
            }
        }
    }

    return false;
}/* End of this function */

int decodeGesture(void)
{
    /* Return if near or far event is detected */
    if( gesture_state_ == NEAR_STATE ) {
        gesture_motion_ = DIR_NEAR;
        return true;
    } else if ( gesture_state_ == FAR_STATE ) {
        gesture_motion_ = DIR_FAR;
        return true;
    }

    /* Determine swipe direction */
    if( (gesture_ud_count_ == -1) && (gesture_lr_count_ == 0) ) {
        gesture_motion_ = DIR_UP;
    } else if( (gesture_ud_count_ == 1) && (gesture_lr_count_ == 0) ) {
        gesture_motion_ = DIR_DOWN;
    } else if( (gesture_ud_count_ == 0) && (gesture_lr_count_ == 1) ) {
        gesture_motion_ = DIR_RIGHT;
    } else if( (gesture_ud_count_ == 0) && (gesture_lr_count_ == -1) ) {
        gesture_motion_ = DIR_LEFT;
    } else if( (gesture_ud_count_ == -1) && (gesture_lr_count_ == 1) ) {
        if( abs(gesture_ud_delta_) > abs(gesture_lr_delta_) ) {
            gesture_motion_ = DIR_UP;
        } else {
            gesture_motion_ = DIR_RIGHT;
        }
    } else if( (gesture_ud_count_ == 1) && (gesture_lr_count_ == -1) ) {
        if( abs(gesture_ud_delta_) > abs(gesture_lr_delta_) ) {
            gesture_motion_ = DIR_DOWN;
        } else {
            gesture_motion_ = DIR_LEFT;
        }
    } else if( (gesture_ud_count_ == -1) && (gesture_lr_count_ == -1) ) {
        if( abs(gesture_ud_delta_) > abs(gesture_lr_delta_) ) {
            gesture_motion_ = DIR_UP;
        } else {
            gesture_motion_ = DIR_LEFT;
        }
    } else if( (gesture_ud_count_ == 1) && (gesture_lr_count_ == 1) ) {
        if( abs(gesture_ud_delta_) > abs(gesture_lr_delta_) ) {
            gesture_motion_ = DIR_DOWN;
        } else {
            gesture_motion_ = DIR_RIGHT;
        }
    } else {
        return false;
    }

    return true;
}/* End of this function */

int apds9960ReadSensor(void)
{
   int Gesture = 0;
   if(isGestureAvailable())
   {
     Gesture = readGesture();
   }

   if (Gesture == DIR_UP){
	   toggleLED(GPIO_Pin_14);
	   turnoffLED(13);
	   turnoffLED(12);
	   turnoffLED(15);
   }
   else if (Gesture == DIR_DOWN){
   	   toggleLED(GPIO_Pin_12);
   	   turnoffLED(14);
   	   turnoffLED(13);
   	   turnoffLED(15);
   }
   else if (Gesture == DIR_LEFT){
   	   toggleLED(GPIO_Pin_13);
   	   turnoffLED(12);
   	   turnoffLED(14);
   	   turnoffLED(15);
   }
   else if (Gesture == DIR_RIGHT){
	   toggleLED(GPIO_Pin_15);
	   turnoffLED(12);
	   turnoffLED(13);
	   turnoffLED(14);
   }

   return Gesture;
}

///*******************************************************************************
//            * End of file *
//*******************************************************************************/
