/*
 * spi.c
 *
 *  Created on: Sep 25, 2019
 *      Author: xiwu
 */

#include "spi_lcd.h"

#include "stm32f4xx.h"
#include "stm32f4xx_spi.h"
#include <stdio.h>
#include <stdlib.h>
#include "stm32f4xx.h"
#include "stm32f4xx_rcc.h"
#include "lcd_display.h"
#include <assert.h>


void hspi_gpio_init(){
    RCC->AHB1ENR |= RCC_AHB1ENR_GPIOAEN;
    RCC->AHB1ENR |= RCC_AHB1ENR_GPIOBEN;
    RCC->APB2ENR |= RCC_APB2ENR_SPI1EN;

		//#define VVC_SWSPI (1)
		  // Initialize the GPIOB pins.
		  // Mode: Output
    GPIOB->AFR[0] |= (5<< (4*3));	//enable SPI CLK to PB3
    GPIOB->AFR[0] |= (5<< (4*4));	//enable MISO to PB4
    GPIOB->AFR[0] |= (5<< (4*5));	//enable MOSI to PB5
		  GPIOB->MODER &=
		      ~((0x3 << (PB_MOSI * 2)) | (0x3 << (PB_SCK * 2)));
		  // Set the MOSI and SCK pins to alternate function mode 0.
		  // Set D/C to normal output.
		  GPIOB->MODER |=
		  		      ((0x2 << (PB_MOSI * 2)) | (0x2 << (PB_SCK * 2)));
		  GPIOB->MODER |=
		      ((0x2 << (PB_MOSI * 2)) | (0x2 << (PB_SCK * 2)));
		  // Use pull-down resistors for the SPI peripheral?
		  // Or no pulling resistors?
		  GPIOB->PUPDR &=
		      ~((0x3 << (PB_MOSI * 2)) | (0x3 << (PB_SCK * 2)));
		  GPIOB->PUPDR |= ((0x1 << (PB_MOSI * 2)) | (0x1 << (PB_SCK * 2)));
		  // Output type: Push-pull
		  GPIOB->OTYPER &= ~((0x1 << PB_MOSI) | (0x1 << PB_SCK));
		  // High-speed - 50MHz maximum
		  // (Setting all '1's, so no need to clear bits first.)
		  GPIOB->OSPEEDR |=
		      ((0x0 << (PB_MOSI * 2)) | (0x3 << (PB_SCK * 2)));
		  // Initialize the GPIOA pins.
		  GPIOA->MODER &= ~((0x3 << (PA_CS * 2)) | (0x3 << (PA_RST * 2)) |  (0x3 << (PA_DC * 2)));
		  GPIOA->MODER |= ((0x1 << (PA_CS * 2)) | (0x1 << (PA_RST * 2)) | (0x1 << PA_DC * 2));
		  GPIOA->OTYPER &= ~((0x1 << PA_CS) | (0x1 << PA_RST) | (0x1 << PA_DC));
		  GPIOA->PUPDR &= ~((0x3 << (PA_CS * 2)) | (0x3 << (PA_RST * 2)) | (0x3 << (PA_DC * 2)));
}

void spi_init(SPI_TypeDef *SPIx) {
  // Ensure that the peripheral is disabled, and reset it.
  //SPIx->CR1 &= ~(SPI_CR1_SPE);
  /*
  if (SPIx == SPI1) {
    RCC->APB2RSTR |= (RCC_APB2RSTR_SPI1RST);
    RCC->APB2RSTR &= ~(RCC_APB2RSTR_SPI1RST);
  }
  */
  // Use unidirectional simplex mode.
  // SPIx->CR1 &= ~(SPI_CR1_BIDIMODE |
  //               SPI_CR1_BIDIOE);
  // Set clock polarity/phase to 0/0?
  SPIx->CR1 &= ~(SPI_CR1_CPOL | SPI_CR1_CPHA);
  // Or 1/1 seems to work...
  SPIx->CR1 |= (SPI_CR1_CPOL | SPI_CR1_CPHA);
  // Set the STM32 to act as a host device.
  SPIx->CR1 |= (SPI_CR1_MSTR);
  // Set software 'Chip Select' pin.
  SPIx->CR1 |= (SPI_CR1_SSM);
  // (Set the internal 'Chip Select' signal.)
  SPIx->CR1 |= (SPI_CR1_SSI);

  SPIx->CR1 |= (SPI_CR1_SPE);
}

void hspi1_init() {
  GPIOA->ODR |= (1 << PA_CS);
  //   (See the 'sspi_cmd' method for 'DC' pin info.)
  GPIOA->ODR |= (1 << PA_DC);
  // Set SCK high to start
  GPIOB->ODR |= (1 << PB_SCK);
  // Reset the display by pulling the reset pin low,
  // delaying a bit, then pulling it high.
  GPIOA->ODR &= ~(1 << PA_RST);
  // Delay at least 100ms; meh, call it 2 million no-ops.
  micro_wait(200000);
  GPIOA->ODR |= (1 << PA_RST);
  micro_wait(200000);
  spi_init(SPI1);
  // Pull CS low.
  GPIOA->ODR &= ~(1 << PA_CS);
  // Initialize the display.
  ili9341_hspi_init(SPI1);
}

void hspi_w8(SPI_TypeDef *SPIx, uint8_t dat) {
  // Wait for TXE.
  while (!(SPIx->SR & SPI_SR_TXE)) {
  };
  // Send the byte.
  //*(uint8_t *)&(SPIx->DR) = dat;
  (SPIx->DR) = dat;
}

void hspi_w16(SPI_TypeDef *SPIx, uint16_t dat) {
  // Wait for TXE.
  while (!(SPIx->SR & SPI_SR_TXE)) {
  };
  // Send the data.
  // (Flip the bytes for the little-endian ARM core.)
  dat = (((dat & 0x00FF) << 8) | ((dat & 0xFF00) >> 8));
  *(uint16_t *)&(SPIx->DR) = dat;
}

void hspi_cmd(SPI_TypeDef *SPIx, uint8_t cmd) {
  while ((SPIx->SR & SPI_SR_BSY)) {
  };
  GPIOA->ODR &= ~(1 << PA_DC);
  hspi_w8(SPIx, cmd);
  while ((SPIx->SR & SPI_SR_BSY)) {
  };
  GPIOA->ODR |= (1 << PA_DC);
}

void ili9341_hspi_init(SPI_TypeDef *SPIx) {
  // (Display off)
  // hspi_cmd(SPIx, 0x28);

  // Issue a series of initialization commands from the
  // Adafruit library for a simple 'known good' test.
  hspi_cmd(SPIx, 0xEF);
  hspi_w8(SPIx, 0x03);
  hspi_w8(SPIx, 0x80);
  hspi_w8(SPIx, 0x02);
  hspi_cmd(SPIx, 0xCF);
  hspi_w8(SPIx, 0x00);
  hspi_w8(SPIx, 0xC1);
  hspi_w8(SPIx, 0x30);
  hspi_cmd(SPIx, 0xED);
  hspi_w8(SPIx, 0x64);
  hspi_w8(SPIx, 0x03);
  hspi_w8(SPIx, 0x12);
  hspi_w8(SPIx, 0x81);
  hspi_cmd(SPIx, 0xE8);
  hspi_w8(SPIx, 0x85);
  hspi_w8(SPIx, 0x00);
  hspi_w8(SPIx, 0x78);
  hspi_cmd(SPIx, 0xCB);
  hspi_w8(SPIx, 0x39);
  hspi_w8(SPIx, 0x2C);
  hspi_w8(SPIx, 0x00);
  hspi_w8(SPIx, 0x34);
  hspi_w8(SPIx, 0x02);
  hspi_cmd(SPIx, 0xF7);
  hspi_w8(SPIx, 0x20);
  hspi_cmd(SPIx, 0xEA);
  hspi_w8(SPIx, 0x00);
  hspi_w8(SPIx, 0x00);
  // PWCTR1
  hspi_cmd(SPIx, 0xC0);
  hspi_w8(SPIx, 0x23);
  // PWCTR2
  hspi_cmd(SPIx, 0xC1);
  hspi_w8(SPIx, 0x10);
  // VMCTR1
  hspi_cmd(SPIx, 0xC5);
  hspi_w8(SPIx, 0x3E);
  hspi_w8(SPIx, 0x28);
  // VMCTR2
  hspi_cmd(SPIx, 0xC7);
  hspi_w8(SPIx, 0x86);
  // MADCTL
  hspi_cmd(SPIx, 0x36);
  hspi_w8(SPIx, 0x48);
  // VSCRSADD
  hspi_cmd(SPIx, 0x37);
  hspi_w8(SPIx, 0x00);
  // PIXFMT
  hspi_cmd(SPIx, 0x3A);
  hspi_w8(SPIx, 0x55);
  // FRMCTR1
  hspi_cmd(SPIx, 0xB1);
  hspi_w8(SPIx, 0x00);
  hspi_w8(SPIx, 0x18);
  // DFUNCTR
  hspi_cmd(SPIx, 0xB6);
  hspi_w8(SPIx, 0x08);
  hspi_w8(SPIx, 0x82);
  hspi_w8(SPIx, 0x27);
  hspi_cmd(SPIx, 0xF2);
  hspi_w8(SPIx, 0x00);
  // GAMMASET
  hspi_cmd(SPIx, 0x26);
  hspi_w8(SPIx, 0x01);
  // (Actual gamma settings)
  hspi_cmd(SPIx, 0xE0);
  hspi_w8(SPIx, 0x0F);
  hspi_w8(SPIx, 0x31);
  hspi_w8(SPIx, 0x2B);
  hspi_w8(SPIx, 0x0C);
  hspi_w8(SPIx, 0x0E);
  hspi_w8(SPIx, 0x08);
  hspi_w8(SPIx, 0x4E);
  hspi_w8(SPIx, 0xF1);
  hspi_w8(SPIx, 0x37);
  hspi_w8(SPIx, 0x07);
  hspi_w8(SPIx, 0x10);
  hspi_w8(SPIx, 0x03);
  hspi_w8(SPIx, 0x0E);
  hspi_w8(SPIx, 0x09);
  hspi_w8(SPIx, 0x00);
  hspi_cmd(SPIx, 0xE1);
  hspi_w8(SPIx, 0x00);
  hspi_w8(SPIx, 0x0E);
  hspi_w8(SPIx, 0x14);
  hspi_w8(SPIx, 0x03);
  hspi_w8(SPIx, 0x11);
  hspi_w8(SPIx, 0x07);
  hspi_w8(SPIx, 0x31);
  hspi_w8(SPIx, 0xC1);
  hspi_w8(SPIx, 0x48);
  hspi_w8(SPIx, 0x08);
  hspi_w8(SPIx, 0x0F);
  hspi_w8(SPIx, 0x0C);
  hspi_w8(SPIx, 0x31);
  hspi_w8(SPIx, 0x36);
  hspi_w8(SPIx, 0x0F);

  // Exit sleep mode.
  hspi_cmd(SPIx, 0x11);
  micro_wait(200000);
  // Display on.
  hspi_cmd(SPIx, 0x29);
  micro_wait(200000);
  // 'Normal' display mode.
  hspi_cmd(SPIx, 0x13);

}


void CleanScreen() {
  // Set column range.
  //set8bmode(SPI1);
  hspi_cmd(SPI1, 0x2A);
  //set16bmode(SPI1);
  hspi_w16(SPI1, 0);
  hspi_w16(SPI1, (uint16_t)(320-1));
  // Set row range.
  hspi_cmd(SPI1, 0x2B);
  hspi_w16(SPI1, (uint16_t)(0));
  hspi_w16(SPI1, (uint16_t)(240-1));
  // Set 'write to RAM'
  hspi_cmd(SPI1, 0x2C);
  uint16_t j = 0;
  //set16bmode(SPI1);
  //micro_wait(20000);
  for (j = 0; j < (240*160); j++) {
  	  hspi_w16(SPI1, ILI9341_RED);
  	  hspi_w16(SPI1, ILI9341_BLUE);
  	  hspi_w16(SPI1, ILI9341_RED);
  	  hspi_w16(SPI1, ILI9341_BLUE);
    }

}

void draw_zero(){
	hspi_cmd(SPI1, 0x2A);
	//set16bmode(SPI1);
	  hspi_w16(SPI1, (uint16_t)(0));
	  hspi_w16(SPI1, (uint16_t)(320-1));
	  //set8bmode(SPI1);
	  // Set row range.
	  hspi_cmd(SPI1, 0x2B);
	  //set16bmode(SPI1);
	  hspi_w16(SPI1, (uint16_t)(0));
	  hspi_w16(SPI1, (uint16_t)(240-1));
	  //set8bmode(SPI1);
	  // Set 'write to RAM'
	  hspi_cmd(SPI1, 0x2C);
	  uint16_t j = 0;
	  //set16bmode(SPI1);
	  for (j = 0; j < (uint16_t)(240) * (uint16_t)(320); j++) {
	  	  hspi_w16(SPI1, ILI9341_RED);
	  	  //micro_wait(200000);
	  	  //set16bmode(SPI1);
	  	  hspi_w16(SPI1, ILI9341_BLUE);
	    }
	  //set16bmode(SPI1);
	  //for (j = 0; j < (uint16_t)(240) * (uint16_t)(160); j++) {
	  	//  hspi_w16(SPI1, ILI9341_BLUE);
	  //}

}

void draw_one(){
	hspi_cmd(SPI1, 0x2A);
	//set16bmode(SPI1);
	  hspi_w16(SPI1, (uint16_t)(0));
	  hspi_w16(SPI1, (uint16_t)(320-1));
	  //set8bmode(SPI1);
	  // Set row range.
	  hspi_cmd(SPI1, 0x2B);
	  //set16bmode(SPI1);
	  hspi_w16(SPI1, (uint16_t)(0));
	  hspi_w16(SPI1, (uint16_t)(240-1));
	  //set8bmode(SPI1);
	  // Set 'write to RAM'
	  hspi_cmd(SPI1, 0x2C);
	  uint16_t j = 0;
	  //set16bmode(SPI1);
	  for (j = 0; j < (uint16_t)(240) * (uint16_t)(160); j++) {
	  	  	  hspi_w16(SPI1, ILI9341_CYAN);
	  	  	  hspi_w16(SPI1, ILI9341_CYAN);
	  	  	  hspi_w16(SPI1, ILI9341_CYAN);
	  	  	  hspi_w16(SPI1, ILI9341_CYAN);
	  	  }/*
	  set16bmode(SPI1);
	  for (j = 0; j < (uint16_t)(240) * (uint16_t)(160); j++) {
	  	  //hspi_w16(SPI1, ILI9341_RED);
	  	  //micro_wait(200000);
	  	  //set16bmode(SPI1);
	  	  hspi_w16(SPI1, ILI9341_CYAN);
	    }
*/

}

void pixel_test(){
	hspi_cmd(SPI1, 0x2A);
	//set16bmode(SPI1);
	  hspi_w16(SPI1, (uint16_t)(50));
	  hspi_w16(SPI1, (uint16_t)(100-1));
	  // Set row range.
		//set8bmode(SPI1);

	  hspi_cmd(SPI1, 0x2B);
		//set16bmode(SPI1);

	  hspi_w16(SPI1, (uint16_t)(50));
	  hspi_w16(SPI1, (uint16_t)(100-1));
		//set8bmode(SPI1);

	  // Set 'write to RAM'
	  hspi_cmd(SPI1, 0x2C);
	  uint16_t j = 0;
		//set16bmode(SPI1);
	  for (j = 0; j < (uint16_t)(50) * (uint16_t)(50); j++) {
	  	  hspi_w16(SPI1, ILI9341_RED);
	  	  micro_wait(200000);
	  	  //hspi_w16(SPI1, ILI9341_BLUE);
	    }
		//set8bmode(SPI1);

}

void setAddrWindow(uint16_t x1, uint16_t y1, uint16_t w, uint16_t h){
	uint16_t x2 = (x1 + w - 1), y2 = (y1 + h - 1);
	// Set column range.
	hspi_cmd(SPI1, 0x2A);

	//set16bmode(SPI1);
	hspi_w16(SPI1, x1);
	hspi_w16(SPI1, x2);
	// Set row range.

	//set8bmode(SPI1);
	hspi_cmd(SPI1, 0x2B);

	//set16bmode(SPI1);
	hspi_w16(SPI1, y1);
	hspi_w16(SPI1, y2);
	// Set 'write to RAM'

	//set8bmode(SPI1);
	hspi_cmd(SPI1, 0x2C);
}

void writeColor(uint16_t color, uint32_t len){
	//set16bmode(SPI1);
	for(int i = 0; i < len; i++){
		hspi_w16(SPI1, color);
	}
	//set8bmode(SPI1);
}

void set16bmode(SPI_TypeDef *SPIx){
	SPIx->CR1 &= ~SPI_CR1_SPE;
	SPIx->CR1 |= SPI_CR1_DFF;
	SPIx->CR1 |= SPI_CR1_SPE;
}
void set8bmode(SPI_TypeDef *SPIx){
	SPIx->CR1 &= ~SPI_CR1_SPE;
	SPIx->CR1 &= ~SPI_CR1_DFF;
	SPIx->CR1 |= SPI_CR1_SPE;
}
